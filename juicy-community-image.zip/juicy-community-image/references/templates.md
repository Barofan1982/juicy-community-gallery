# 构图、题目与提示词模板

先选用途。社群参与是“看清问题 → 回答/表达偏好”；买量图是“理解一个有趣场景 → 进入游戏”。参考图有选项不代表 JJ 有这个真实玩法。用户只借画风时无需竞猜。默认不写奖励数量，不带数量占位符，不自动加入任何抽奖文案。

## 题目优先级

| 模板 | 参考 | 适合 JJ 的题材 | 必查逻辑 |
|---|---|---|---|
| 手持目标 + 三个候选 | T013 | Sera 的水果饮料找同款 | 正确杯子的果片/颜色/杯型/吸管一致；其它不同 |
| 中央完整食物 + 两片候选 | T007 / T016 | 汉堡、派、蛋糕剖面 | 食材顺序、层数、切口对应 |
| 两列四行配对 | T064 / T078 | 水果与果汁、原料与料理 | 目标一一对应；右列顺序打乱 |
| 照片 + 场景找同款 | T028 | 窗口 Oli、餐厅桌面 | 视角可比较；相同对象与姿势只有一个 |
| 放大局部 + 三张头像 | T089 | 宠物项圈、Oli 围巾 | 毛发/围巾线索唯一；其它选项不要复制同线索 |
| 物体缺位 + 三选一 | T061 / T045 | 甜点装饰、仓库钥匙 | 缺口与选项轮廓一致且唯一 |
| 左右偏好投票 | T043 / T056 | 两种海岛餐厅、不同饮料 | 不需要正确答案；别把喜好题写成智力题 |
| 生活场景 + 短标题 | T090 / T006 | 海岛经营、美食准备 | 不发明上线状态或促销信息 |

脚印、剪影、管道、迷宫与镜子构图更易出错。先确定连通路径、遮挡关系或反射规则，再生成。密集微缩地图与植物种子细节不适合小屏，优先简化。

## 题目内部规格

对每张竞猜图保留一个小规格，不必把答案写进成品：

```text
问题：哪杯和 Sera 手中的饮料相同？
目标：透明高杯；橙色液体；橙片在杯口；橘色弯吸管；无伞。
A：红色草莓汁，草莓装饰，直吸管。
B：与目标一致。
C：黄色菠萝汁，菠萝装饰，小纸伞。
内部答案：B；唯一性线索：水果装饰 + 液体颜色 + 无伞。
```

像素里必须画出这些特征。如果模型画成 A/B 同款，先修再交付。不要为了难度把所有区别压到一粒芝麻或几像素。

## 提示词底座

把尖括号填成具体内容，再调用；不能把未填字段或互相矛盾的模式一起交给模型。

```text
Use case: ads-marketing.
Asset type: <community engagement illustration OR mobile game acquisition still> for Juicy Journey.
Create one <ratio> full-bleed opaque image.
Inputs: Image 1 is ONLY a rendering/composition reference; do not copy its brand, characters, reward badge or exact scene. Image 2 is the authoritative <Sera/Oli> identity reference. Image 3 is the official Juicy Journey logo if requested.
Primary scene: <one concrete action or visual question> in <JJ tropical kitchen/cafe/island scene>.
Identity: Preserve the official character's recognizable features and species from the identity input, adapted to the soft illustration finish. <scene-specific costume if needed>.
Look: polished casual-mobile-game cartoon illustration, softly modeled 2.5D forms with a stylized 3D finish, rounded readable shapes, clean painted gradients, warm diffused lighting, gentle ambient occlusion, tactile wood/fabric/fur/food, controlled highlights. Lush but visually organized backdrop.
Composition: <target position; protagonist gesture; option positions; headline/logo zone; safe margins>. Keep the key clue and all option labels unobstructed and readable at small size.
Question logic: <target; candidates; exact visual relationships; correct answer for internal generation only OR subjective preference with no correct answer>.
Text (verbatim): <only the exact approved headline, labels, CTA, and brand if requested>. Do not add other captions.
Constraints: no reward quantities, no prize-count placeholders, no copied reward corner badge, no Tasty Travels branding or character identity. No unsupported gameplay interface, activity deadline, giveaway claim, guaranteed reward, or performance claim. <actual hand/reflection/clue invariants>.
```

`Use case` 是提示词标签，不是生图工具参数。不要凭空指定工具不支持的 size/quality/output-path 字段；尺寸和比例写进提示词并检查实际返回像素。若要精确投放尺寸，依据当前工具能力与用户要求制作，不默认为必须某一个生成像素。

## 已填示例 1：Sera 果汁找同款（社群）

参考顺序：assets/style-references/T013.jpg；官方 Sera；官方英文 Logo。场景不必重画原图躺椅。

```text
Use case: ads-marketing. Create one square community quiz illustration for Juicy Journey.
Image 1 is only a reference for soft polished cartoon rendering and the hand-held-target versus three-drinks layout. Images 2 and 3 provide authoritative Sera identity and the English Juicy Journey logo. Redesign the scene; do not copy the reference girl's face, hair, eyes, logo, or reward badge.
Scene: a sunny open-air tropical juice cafe, pale warm timber counter, distant turquoise sea and a few palm leaves. Adult Sera smiles in three-quarter view behind the counter, holding one clear tall glass of orange juice near her chest. Keep her orange-red hair, emerald green eyes, subtle freckles and gold star earrings recognizable, based on image 2; use a light cafe apron appropriate to the setting.
Finish: warmly lit refined 2.5D cartoon commercial illustration with a stylized 3D finish, soft clean gradients, rounded shapes, tactile cotton and wood, delicious glossy fruit, translucent drink glasses, gentle shadows, restrained highlights. Background stays quieter than the four drinks.
Place three candidate glasses evenly across the lower-middle foreground, all at matching scale. Target drink has orange liquid, one orange wheel on the rim and a bent orange straw, with no umbrella. A is red strawberry juice with a strawberry and a straight red straw. B matches the target exactly: orange liquid, one orange wheel, bent orange straw, no umbrella. C is yellow pineapple juice with a pineapple wedge and a tiny paper umbrella. Keep every garnish and straw visible. B is the unique internal answer; do not reveal the answer in the image.
Place the official supplied logo at upper left, preserving its yellow/aqua lettering, purple silhouette and white edge without its black display canvas. Short cream rounded bold headline at lower edge, restrained dark-teal outline: "Which One Matches?". Small wood option labels "A", "B", "C" directly below their respective glasses. These labels, the headline and supplied logo are the only text. No install button for this community version.
No reward quantities, no reward badge, no giveaway claim, no copied competitor identities, no duplicated glasses, no obscured clues, no cropped hands or text. One clear light visual quiz.
```

## 已填示例 2：水果与果汁配对（买量构图）

参考 T078 的面板与 T064 的角色位置；身份用 Oli。为避免社群 CTA 与买量混淆，按本轮需求选 PLAY NOW 或 LEARN MORE；没有指定时可以给短文案建议，不添加留言抽奖。

```text
Use case: ads-marketing. One square Juicy Journey creative concept, not an in-game screenshot.
Input 1 is only the warm cartoon two-column board layout reference. Input 2 is authoritative Oli identity. Input 3 is the official English Juicy Journey logo.
In a bright tropical fruit cafe, place a large rounded light-wood board center-right and official Oli at lower-left pointing toward it. Oli is a honey-brown OTTER with small rounded ears, cream muzzle and belly, round brown eyes, little whiskers, blue neckerchief and a plain unstriped tapering otter tail. Never draw a red panda mask, pointed ears or ringed tail.
Four evenly spaced cream cards in the left column: A apple, B orange, C purple grapes, D strawberry. Four evenly spaced right cards: 1 orange juice with orange slice, 2 grape juice with grape garnish, 3 apple juice with apple slice, 4 strawberry juice with strawberry. Each ingredient appears once; each drink appears once. Pairing is A3, B1, C2, D4, for internal reference only. Do not draw connecting lines or show the answer.
Refined soft 2.5D cartoon illustration with rounded forms and stylized 3D finish; warm sunlight, mint accents, honey wood, smooth fruit highlights. Clues and labels are more prominent than background leaves. Keep the logo at upper-left, accurate to the supplied asset, and all eight item labels clear.
Exact headline: "Find the Perfect Match!". Exact CTA: "PLAY NOW" in one small teal rounded button below the board. Only the headline, CTA, option letters/numbers and official logo are allowed text. No reward quantities or badge, no claims that this quiz is actual JJ gameplay, no gift promises, no competitor mascot or brand.
```

## 已填示例 3：只借画风的海岛料理日常

```text
Use case: ads-marketing. Create one square Juicy Journey advertising illustration.
Use the competitor cafe/building image only for warm lighting, rounded polished illustration and organized scenic detail. Official Sera and Oli inputs control identity; the supplied JJ logo controls branding.
Adult Sera places a fresh fruit tart on a pale wooden table at a tropical seaside cafe while official Oli, a small honey-brown otter with round ears, cream muzzle, blue neckerchief and an unstriped tail, leans forward with a delighted expression. Sera retains her official orange-red hair, green eyes, freckles and gold star earrings. One action: the shared moment of presenting a beautiful tart. Clearly visible fruit and crust are the foreground focus; palms, aqua sea and warm cafe furnishings form a quiet backdrop.
Soft refined 2.5D cartoon illustration with a stylized 3D finish, clean gradients, appetizing restrained highlights, tactile fabric and wood, warm diffused daylight. Keep adult Sera proportions and readable expressions. Leave comfortable upper-corner logo space and clean lower text space.
Place the official JJ logo upper-left, accurate shape and colors, without its black source canvas. Exact headline: "A Taste of Island Life". Exact CTA: "LEARN MORE". No other text, no choices, no quiz board, no reward quantity or badge, no gifts or deadline claims, no competitor identity.
```

## 独立奖励组件（仅后续用户明确需要时）

先确认本轮要“无数字奖品图标”还是“用户给定数字的角标”。使用本品实际资源图作为参考，不把竞品 ×200 再利用。角标需要透明时单独生成透明 PNG，图标、数字与描边在一个明确形状内，边缘无背景残留。未提供数量时交付无数字版，不用问号或 ×N 顶替。它是独立组件，主图要不要加、放哪里，以用户当前指示为准。
